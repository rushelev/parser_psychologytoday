from json import dump as json_dump
from json import load as json_load
import os
import sys
import hashlib


def get_only_alpha_from_list(check_list):
    clear_list = list()
    for item in check_list:
        item = ''.join(x for x in item if x.isalpha())
        if item:
            clear_list.append(item)
    return clear_list


def add_to_json_list(wr_list, name_json):
    temp_list = list()
    if os.path.exists(name_json):
        with open(name_json, 'r', encoding='utf-8') as file:
            temp_list = list(json_load(file))
    temp_list.extend(wr_list)
    temp_list = list(set(temp_list))
    with open(name_json, 'w', encoding='utf-8') as file:
        json_dump(temp_list, file, indent=4, ensure_ascii=False)


def add_to_txt_list(wr_list, name_txt):
    with open(name_txt, 'a', encoding='utf-8') as file:
        temp = ';'.join(wr_list)
        file.write('{};'.format(temp))


def remove_from_list_in_json(item, name_json):
    with open(name_json, 'r', encoding='utf-8') as file:
        temp_list = list(json_load(file))
    temp_list.remove(item)
    with open(name_json, 'w', encoding='utf-8') as file:
        json_dump(temp_list, file, indent=4, ensure_ascii=False)


def write_failed_profile(link):
    with open(os.path.join('failed_profiles', get_id(link)), 'w') as file:
        file.write(link)


def get_id(string):
    id = hashlib.md5()
    id.update(string.encode())
    return id.hexdigest()


def get_base_links(base_dict):
    url = 'https://www.psychologytoday.com'
    res = list()
    for k, v in base_dict.items():
        for i in v:
            res.append('{}/{}/{}'.format(url, k, i))
    return res


def write_list_to_json(wr_list, name_json):
    with open(name_json, 'w', encoding='utf-8') as file:
        json_dump(wr_list, file, indent=4, ensure_ascii=False)


def write_warning(link, name):
    with open(name, 'a') as file:
        file.write("{};\n".format(link))


def read_json(file):
    if os.path.exists(file):
        with open(file, 'r', encoding='utf-8') as file:
            temp_dict = json_load(file)
        return temp_dict
    else:
        print('Reading {} failed'.format(file))
        sys.exit(1)


def read_json_upload(file):
    if os.path.exists(file):
        with open(file, 'r', encoding='utf-8') as file:
            temp_dict = json_load(file)
        return temp_dict
    else:
        print('Upload firstly')
        return list()


def read_file(file):
    if os.path.exists(file):
        with open(file, 'r', encoding='utf-8') as file:
            text = file.read()
        return text
    else:
        print('Reading {} failed'.format(file))


if __name__ == '__main__':
    print("Module > links.py")
