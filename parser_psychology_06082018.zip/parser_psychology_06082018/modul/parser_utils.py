from urllib.request import Request
import urllib.request
from bs4 import BeautifulSoup
import urllib.request
from time import sleep
from modul import links
from os import path, listdir
from selenium import webdriver
import random



def get_unic_links(input):
    unic_list = list()
    for link in input:
        temp_link = link[8:].split('/')
        temp_link[-1] = temp_link[-1][:temp_link[-1].find('?')]
        link = 'https://{}'.format('/'.join(temp_link))
        unic_list.append(link)
    return unic_list



def txt_to_list(path_to_file):
    if path.exists(path_to_file):
        with open(path_to_file, 'r') as file:
            temp = file.read()
        list_mails = temp[:-1].split(';')
        return list_mails
    else:
        return False



def get_next_id(first_link, second_link):
    splited_first = first_link.split('rec_next=')
    splited_second = second_link.split('rec_next=')
    if len(splited_first) == 2 and len(splited_second) ==2:
        index_next = int(splited_first[-1])+20
        temp = '{}rec_next={}'.format(splited_first[0], index_next)
        return temp
    else:
        return second_link

def get_next_id_old(first_link, second_link):
    splited_first = first_link.split('rec_next=')
    splited_second = second_link.split('rec_next=')
    if len(splited_first) == 2 and len(splited_second) ==2:
        if splited_first[-1] == splited_second[-1]:
            index_next = int(splited_first[-1])+20
            temp = '{}rec_next={}'.format(splited_first[0], index_next)
            print('OWN CREATE next link:',temp)
            return temp
        if int(splited_first[-1])> int(splited_second[-1]):
            print(int(splited_first[-1]))
            return first_link
    return second_link



def check_internet():
    try:
        urllib.request.urlopen('http://216.58.192.142', timeout=10)
        return True
    except Exception as err:
        print('Connection failed: ', err)
        return False


def get_html(url):
    while True:
        if check_internet():
            break
        else:
            print('Check internet connection')
            sleep(10)
    while True:
        try:
            driver = webdriver.PhantomJS(executable_path='./phantomjs')
            driver.set_page_load_timeout(60)
            driver.get(url)
            res = driver.page_source
            driver.quit()
            break
        except Exception as e:
            print('Error in get_html: ', e)
            try:
                driver.quit()
            except:
                pass
            sleep(5)
    return res


def get_html_profile(url):
    while True:
        if check_internet():
            break
        else:
            print('Check internet connection')
            sleep(30)

    while True:
        try:
            driver = webdriver.PhantomJS(executable_path='./phantomjs')
            driver.set_page_load_timeout(60)
            driver.get(url)
            res = driver.page_source
            driver.quit()
            break
        except Exception as e:
            print('Error in get_html_profile (getting profile failed link {}): {}'.format(url, e))
            try:
                driver.quit()
            except:
                pass
            sleep(random.randint(5, 10))

    return res



def read_html_zip(html_page, link):
    soap = BeautifulSoup(html_page, "html.parser")
    state_block = soap.find('div', {'id': 'nbhdPostalCodes'})
    if state_block:
        link_cities = set([x['href'] for x in state_block.find_all('a')])
        print('+{} cities'.format(len(link_cities)))
        return list(link_cities)
    else:
        clear_list = list()
        clear_list.append(link)
        return clear_list


def read_html_cities(html_page, link):
    soap = BeautifulSoup(html_page, "html.parser")
    state_block = soap.find('div', {'id': 'RefineCitiesCountiesToggle'})
    if state_block:
        link_cities = set([x['href'] for x in state_block.find_all('a', {'data-event-label': 'RefineCityLink'})])
        print('+{} cities'.format(len(link_cities)))
        return list(link_cities)
    else:
        print('Check link: {}'.format(link))
        return list()




def read_html_states(html_page):
    soap = BeautifulSoup(html_page, "html.parser")
    state_block = soap.find_all('div', 'row listItems')
    if len(state_block):
        state_block = state_block[1]
        link_states = [x['href'] for x in state_block.find_all('a')]
        print('+{} states'.format(len(link_states)))
        return link_states
    else:
        print('Check: {}'.format(html_page))
        return list()


def read_html_profiles(html_page, link):
    print(link)
    soap = BeautifulSoup(html_page, "html.parser")
    main_block = soap.find('div', 'col-12 col-sm-12 col-md-12 col-lg-10 push-lg-2 results-column')
    if not main_block:
        print('Warning: no structure on page {}'.format(link))
        links.write_warning(link, 'warning_links.txt')
        return list()
    profiles = main_block.find_all('a', 'result-name')
    if len(profiles):
        profiles_links = [x['href'] for x in profiles]
        next_button = soap.find('a', 'btn btn-default btn-next')
        print('Profiles on page: {}'.format(len(profiles_links)))
        if next_button:
            next_page = next_button['href']
            profiles_links.extend(read_html_profiles(get_html(next_page), next_page))
        return profiles_links
    else:
        links.write_warning(link, 'waning_links.txt')
        print('Warrning: no items on page {}'.format(link))


def read_html_profiles_v2(html_page, link, name):
    soap = BeautifulSoup(html_page, "html.parser")
    main_block = soap.find('div', 'col-12 col-sm-12 col-md-12 col-lg-10 push-lg-2 results-column')
    if not main_block:
        print('Warning: no structure on page {}'.format(link))
        links.write_warning(link, 'warning_links.txt')
        return False
    print("Link: {}; Name: {}".format(link, name))
    profiles = main_block.find_all('a', 'result-name')
    if len(profiles):
        profiles_links = get_unic_links([x['href'] for x in profiles])
        next_button = soap.find('a', 'btn btn-default btn-next')
        print('Profiles on page: {}'.format(len(profiles_links)))
        alredy_uploaded_profiles = txt_to_list(path.join('cities_links', str(name)))
        if alredy_uploaded_profiles:
            count = 0
            for i in profiles_links:
                if i in alredy_uploaded_profiles:
                    count += 1
            if count == len(profiles_links):
                links.write_warning(link,'last_page.txt')
                print('PROFILES ALREADY IN FILE. EXIT.', name)
                return False
        links.add_to_txt_list(profiles_links, path.join('cities_links', str(name)))
        if next_button:
            next_page = get_next_id(link, next_button['href'])
            # if link == next_page:
            #     print('\n')
            #     print('LINK = NEXT. In warning: {}\n'.format(link))
            #     links.write_warning(link, 'warning_profiles.txt')
            #     sleep(3)
            #     return  False
            read_html_profiles_v2(get_html(next_page), next_page, name)
    else:
        links.write_warning(link, 'warning_profiles.txt')
        print('Warrning: no items on page {}'.format(link))


def parse_profiles(html, link):
    info_dict = {
        "address": {
            "city": "None",
            "country": "None",
            "line1": "None",
            "line2": "None",
            "state": "None",
            "zip": "None"
        },
        "nearbyAreas": {
            "cities": [],
            "zip": [],
            "counties": []
        },
        "additionalLocations": {
            "city": "None",
            "country": "None",
            "line1": "None",
            "line2": "None",
            "state": "None",
            "zip": "None",
            "phone": "None"
        },
        "psycTodayWebsite": "None",
        "bio": "None",
        "finance": {
            "fee": {
                "max": 0,
                "min": 0
            },
            "payment_method": []
        },
        "id": "None",
        "name": {
            "first": "None",
            "full": "None",
            "last": "None"
        },
        "phone": "None",
        "photo": {
            "s3path": "None"
        },
        "qualifications": {
            "board_certifications": "None",
            "experience": "None",
            "graduation_year": "None",
            "license_num": "None",
            "license_state": "None",
            "school": "None"
        },
        "specialty": [],
        "title": "None",
        "types_of_therapy": [],
        "website": str(link),
        "works_with": {
            "ages": [],
            "concerns": [],
            "groups": [],
            "mental_health": [],
            "ethnicity": "None"
        },
        "insurance": [],
        "languages": "None",
        "modality": [],
        "religion": "None",
        "sexuality": [],
        "second_title": "None"
    }
    main_block = BeautifulSoup(html, "html.parser")
    main_info = main_block.find('div', 'profile-middle profile-flag col-12 col-sm-12 col-md-10 col-lg-10')
    if not main_info:
        links.write_failed_profile(link)
        return 1
    # addr filds
    city = main_block.find('span', {'itemprop': 'addressLocality'})
    if city:
        info_dict["address"]["city"] = city.text.strip()

    addressRegion = main_block.find('span', {'itemprop': 'addressRegion'})
    if addressRegion:
        info_dict["address"]["state"] = addressRegion.text.strip()

    postalcode = main_block.find('span', {'itemprop': 'postalcode'})
    if postalcode:
        info_dict["address"]["zip"] = postalcode.text.strip()

    country = main_block.find('span', 'country-display')
    if country:
        info_dict["address"]["country"] = country.text.strip()

    line1 = main_block.find('span', {'itemprop': 'streetAddress'})
    if line1:
        info_dict["address"]["line1"] = line1.text.strip()
        if str(line1.nextSibling).strip() == '<br/>':
            line2 = str(line1.nextSibling.next).strip()
            if line2:
                info_dict["address"]["line2"] = line2


    #additionalLocation
    h2_additional = main_block.find('h2','additional-location')
    if h2_additional:
        additional_block = h2_additional.find_next_sibling()
        city = additional_block.find('span', {'itemprop': 'addressLocality'})
        if city:
            info_dict["additionalLocations"]["city"] = city.text.strip()

        addressRegion = additional_block.find('span', {'itemprop': 'addressRegion'})
        if addressRegion:
            info_dict["additionalLocations"]["state"] = addressRegion.text.strip()

        postalcode = additional_block.find('span', {'itemprop': 'postalcode'})
        if postalcode:
            info_dict["additionalLocations"]["zip"] = postalcode.text.strip()

        if country:
            info_dict["additionalLocations"]["country"] = country.text.strip()

        line1 = additional_block.find('span', {'itemprop': 'streetAddress'})
        if line1:
            info_dict["additionalLocations"]["line1"] = line1.text.strip()
            if str(line1.nextSibling).strip() == '<br/>':
                line2 = str(line1.nextSibling.next).strip()
                if line2:
                    info_dict["additionalLocations"]["line2"] = line2
        # Local_phone
        local_phone = additional_block.find('a', 'phone-number')
        if local_phone:
            info_dict["additionalLocations"]["phone"] = local_phone.text.strip()


    # nearby area
    nearby_block = main_block.find('div', {'data-event-label' : 'Nearby'})
    if nearby_block:
        all_h5 = nearby_block.find_all('h5')
        if all_h5:
            for item in all_h5:
                parametr = item.text.strip()
                if parametr == 'Cities:':
                    temp_ul = item.find_next('ul')
                    if temp_ul:
                        info_dict["nearbyAreas"]["cities"] = (([x.text.strip() for x in temp_ul.find_all('li')]))
                if parametr == 'Counties:':
                    temp_ul = item.find_next('ul')
                    if temp_ul:
                        info_dict["nearbyAreas"]["counties"] = (([x.text.strip() for x in temp_ul.find_all('li')]))
                if parametr == 'Zips:':
                    temp_ul = item.find_next('ul')
                    if temp_ul:
                        info_dict["nearbyAreas"]["zip"] = (([x.text.strip().split()[0] for x in temp_ul.find_all('li') if x]))

    #Website
    web_site_profile = main_block.find('a', {'data-event-label' : 'website'})
    if web_site_profile:
        info_dict["psycTodayWebsite"] = web_site_profile['href']

    # bio
    bio = main_block.find('div', 'section profile-personalstatement')
    if bio:
        temp_list = (bio.text.strip().replace('\n', '')).split()
        string_bio = ' '.join(temp_list)
        if len(string_bio) > 2:
            info_dict["bio"] = string_bio

    # finance
    finance_block = main_block.find('div', 'profile-finances details-section top-border')
    if finance_block:
        finance_block_strongs = finance_block.find_all('strong')
        finance_block_spans = finance_block.find_all('span')
        if finance_block_strongs:
            for item in finance_block_strongs:
                parametr = item.text.strip()
                if parametr == 'Avg Cost (per session):':
                    cost = item.nextSibling
                    if cost:
                        cost_list = cost.strip().split('-')
                        clear_digist = list()
                        for item in cost_list:
                            item = ''.join(x for x in item if x.isdigit())
                            if item:
                                clear_digist.append(int(item))

                        len_cost_list = len(clear_digist)
                        if len_cost_list == 2:
                            info_dict['finance']['fee']['min'] = int(clear_digist[0])
                            info_dict['finance']['fee']['max'] = int(clear_digist[1])
                        elif len_cost_list == 1:
                            info_dict['finance']['fee']['min'] = int(clear_digist[0])
                            info_dict['finance']['fee']['max'] = int(clear_digist[0])
                        else:
                            print('CHECK LINK FOT FINANCE:', link)
            for item in finance_block_spans:
                parametr = item.text.strip()
                if parametr == 'Accepted Payment Methods:':
                    temp_list = [x.text.strip() for x in finance_block_spans[int(finance_block_spans.index(item)) + 1:]]
                    info_dict['finance']["payment_method"] = links.get_only_alpha_from_list(temp_list)

    # second_title
    profile_title = main_block.find('div', 'profile-title')
    if profile_title:
        info_dict['second_title'] = ' '.join([x.strip() for x in profile_title.text.split() if x])

    # profile
    profile_container = main_block.find('div', {'id': 'profileContainer'})
    # name
    full_name = profile_container.get('data-prof-name').strip()
    info_dict['name']['full'] = full_name
    temp_list = full_name.split()
    if len(temp_list) == 1:
        first_name = temp_list[0]
        info_dict['name']['first'] = first_name
    elif len(temp_list) >= 2:
        first_name = temp_list[0]
        info_dict['name']['first'] = first_name
        last_name = ' '.join(temp_list[1:])
        info_dict['name']['last'] = last_name
    # telephone
    try:
        telephone = profile_container.get('data-phone').strip()
        info_dict['phone'] = telephone.strip()
    except Exception:
        pass

    # id
    info_dict["id"] = links.get_id("{}{}".format(info_dict['name']['full'], info_dict["address"]["zip"]))

    # qualification
    qualification_container = main_block.find('div', 'profile-qualifications details-section')
    if qualification_container:
        qualification_container_strongs = qualification_container.find_all('strong')
        if qualification_container_strongs:
            for item in qualification_container_strongs:
                parametr = item.text.strip()
                if parametr == 'Board Certification:':
                    info_dict['qualifications']['board_certifications'] = item.nextSibling.strip()
                elif parametr == 'Year Graduated:':
                    info_dict['qualifications']['graduation_year'] = item.nextSibling.strip()
                elif parametr == 'School:':
                    info_dict['qualifications']['school'] = item.nextSibling.strip()
                elif parametr == 'Years in Practice:':
                    info_dict['qualifications']['experience'] = item.nextSibling.strip()
                elif parametr == 'License No. and State:':
                    temp_list = item.nextSibling.strip().split()
                    if len(temp_list) == 2:
                        info_dict['qualifications']['license_num'] = temp_list[0]
                        info_dict['qualifications']['license_state'] = temp_list[1]
                    elif len(temp_list) > 2:
                        info_dict['qualifications']['license_num'] = temp_list[0]
                        info_dict['qualifications']['license_state'] = ' '.join(temp_list[1:])

    # title
    try:
        title = main_block.find('meta', {'name': 'dcterms.title'}).get('content')
        info_dict['title'] = title
    except Exception:
        pass

    # speciality
    spec_container = main_block.find('ul', 'attribute-list specialties-list')
    if spec_container:
        spec_list = [x.text.strip() for x in spec_container.find_all('li')]
        info_dict['specialty'] = spec_list

    # types_of_therapy
    all_spec_h5 = main_block.find_all('h5', 'spec-subcat')
    if all_spec_h5:
        for item in all_spec_h5:
            parametr = item.text.strip()
            if parametr == 'Types of Therapy':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['types_of_therapy'] = ([x.text.strip() for x in temp_ul.find_all('li')])
            elif parametr == 'Age':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['works_with']['ages'] = ([x.text.strip() for x in temp_ul.find_all('li')])
            elif parametr == 'Issues':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['works_with']['concerns'] = ([x.text.strip() for x in temp_ul.find_all('li')])
            elif parametr == 'Modality':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['works_with']['groups'] = ([x.text.strip() for x in temp_ul.find_all('li')])
            elif parametr == 'Mental Health':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['works_with']['mental_health'] = ([x.text.strip() for x in temp_ul.find_all('li')])
            elif parametr == 'Mental Health':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['works_with']['mental_health'] = ([x.text.strip() for x in temp_ul.find_all('li')])
            elif parametr == 'Accepted Insurance Plans':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['insurance'] = ([x.text.strip() for x in temp_ul.find_all('li')])
            elif parametr == 'Modality':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['modality'] = ([x.text.strip() for x in temp_ul.find_all('li')])
            elif parametr == 'Sexuality':
                temp_ul = item.find_next('ul', 'attribute-list copy-small')
                if temp_ul:
                    info_dict['sexuality'] = ([x.text.strip() for x in temp_ul.find_all('li')])

    # etnist
    etnisity_block = main_block.find('div', 'spec-subcat attributes-ethnicity-focus')
    if etnisity_block:
        info_dict['works_with']['ethnicity'] = ' '.join([x.text for x in etnisity_block.find_all('span')[1:]])

    # language
    language_block = main_block.find('div', 'spec-subcat attributes-language')
    if language_block:
        info_dict['languages'] = ' '.join([x.text for x in language_block.find_all('span')[1:]])

    # religious
    relig_block = main_block.find('div', 'spec-subcat attributes-religion')
    if relig_block:
        info_dict['religion'] = ' '.join([x.text for x in relig_block.find_all('span')[1:]])

    # group_block (for support groups)
    all_h3 = main_block.find_all('h3')
    if all_h3:
        for item in all_h3:
            parametr = item.text.strip()
            if parametr == 'Group Details':
                group_block = item.find_next('div', 'row')
                if group_block:
                    all_parametrs = group_block.find_all('div', 'group-detail')
                    if all_parametrs:
                        for i in all_parametrs:
                            name_param = i.find('strong')
                            if name_param:
                                param = name_param.text.strip()
                                if param == 'Issues:':
                                    info_dict['works_with']['concerns'] = [x.strip() for x in
                                                                           name_param.nextSibling.strip().split(',')]
                                if param == 'Sexuality:':
                                    info_dict['sexuality'] = [x.strip() for x in
                                                              name_param.nextSibling.strip().split(',')]
                                if param == 'Age:':
                                    info_dict['works_with']['ages'] = [x.strip() for x in
                                                                       name_param.nextSibling.strip().split(',')]
                                if param == 'Types of Therapy:':
                                    info_dict['types_of_therapy'] = [x.strip() for x in
                                                                     name_param.nextSibling.strip().split(',')]
                                if param == 'Session Cost:':
                                    cost = name_param.find_next('p')
                                    if cost:
                                        cost_list = cost.text.strip().split('-')
                                        clear_digist = list()
                                        for item in cost_list:
                                            item = ''.join(x for x in item if x.isdigit())
                                            if item:
                                                clear_digist.append(int(item))

                                        len_cost_list = len(clear_digist)
                                        if len_cost_list == 2:
                                            info_dict['finance']['fee']['min'] = int(clear_digist[0])
                                            info_dict['finance']['fee']['max'] = int(clear_digist[1])
                                        elif len_cost_list == 1:
                                            info_dict['finance']['fee']['min'] = int(clear_digist[0])
                                            info_dict['finance']['fee']['max'] = int(clear_digist[0])

    # image
    image = main_block.find('img', {'data-event-label': 'Photo_ModalLink'})
    if image:
        image_link = image['src']
        name_img = '{}.jpg'.format(info_dict['id'])
        urllib.request.urlretrieve(image_link, path.join('images', name_img))
        info_dict['photo']['s3path'] = name_img

    # write dict to json
    links.write_list_to_json(info_dict, path.join('json_files', links.get_id(link)))


def get_unic_urls(list_1, list_2):
    return [i for i in list_1 if i not in list_2]


def get_failed_links():
    failed_profiles = listdir('failed_profiles')
    failed_list = list()
    if failed_profiles:
        failed_list = [links.read_file(path.join('failed_profiles', x)) for x in failed_profiles]
    return failed_list


def get_success_links():
    sc_profiles = listdir('json_files')
    sc_list = list()
    if sc_profiles:
        sc_list = [links.read_json(path.join('json_files', x))["website"] for x in sc_profiles]
    return sc_list


def get_list_urls_for_pars(profiles_file):
    list_1 = get_failed_links()
    list_2 = get_success_links()
    list_1.extend(list_2)
    profiles = links.read_json(profiles_file)
    unic_list = get_unic_urls(set(profiles), set(list_1))
    print("Links for pars: {}".format(len(unic_list)))
    return unic_list


if __name__ == '__main__':
    print("Module > parser_utils.py")
