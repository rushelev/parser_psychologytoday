from modul import links


def get_unic(list_with_files):
    res_list = list()
    for item in list_with_files:
        temp = list(set(links.read_json(item)))
        print("{} : {}".format(item, len(temp)))
        res_list.extend(temp)
    return list(set(res_list))


files = ['old_upload.json', 'temp_profiles_1.json', 'temp_profiles_2.json', 'temp_profiles_3.json', 'temp_profiles_4.json']
res = get_unic(files)
print('Result:', len(res))
links.write_list_to_json(res,'profiles.json')
