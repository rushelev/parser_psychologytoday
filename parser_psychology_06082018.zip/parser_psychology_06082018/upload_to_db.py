import boto3
from os import listdir
from modul import links
from modul import parser_utils
from os import path
import sys
from multiprocessing import Pool, Process


def push_item(table, item):
    res = table.put_item(Item=item)
    if not res["ResponseMetadata"]["HTTPStatusCode"] == 200:
        return False
    else:
        return True


def dell_item(table, item):
    table.delete_item(Key=item)


def print_item(table, item):
    response = table.get_item(
        Key=item
    )
    item = response['Item']
    print(item)


def dynamodb():
    dynamodb = boto3.resource('dynamodb', aws_access_key_id='AKIAJZRRWYO7JPGVT2SA',
                              aws_secret_access_key='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',
                              region_name='us-east-1')
    table = dynamodb.Table('therapists_test')
    push_item(table, 'json_files/0000c928312123ca35863822146531a5')


def upload_image(item):
    s3 = boto3.client('s3', aws_access_key_id='AKIAI4DZTYTF36R2466A',
                      aws_secret_access_key='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',
                      region_name='us-east-1')
    BUCKET_NAME = 'better-therapists'
    KEY_PREFIX = 'images/all/'
    key = "{}{}".format(KEY_PREFIX, item)
    try:
        with open('images/{}'.format(item), 'rb') as data:
            s3.upload_fileobj(data, BUCKET_NAME, key)
        open(path.join('uploaded_images', item), 'w').close()
        print(item)
    except Exception as error:
        print(error)


def upload_json(item):
    dynamodb = boto3.resource('dynamodb', aws_access_key_id='AKIAI4DZTYTF36R2466A',
                              aws_secret_access_key='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',

                              region_name='us-east-1')

    try:
        info_dict = links.read_json(path.join('json_files', item))
        # check json
        for k, v in info_dict.items():
            if v == "":
                info_dict[k] = "None"
            elif type(v) == dict:
                for in_k, in_v in info_dict[k].items():
                    if in_v == "":
                        info_dict[k][in_k] = "None"
                    if type(in_v) == list:
                        info_dict[k][in_k] = [x for x in in_v if x ]
            elif type(v) == list:
                info_dict[k] = [x for x in v if x ]
        # select category
        temp_list = info_dict["website"].split('/')
        if 'counselling' in temp_list:
            table = dynamodb.Table('Counseling')
        elif 'therapists' in temp_list:
            table = dynamodb.Table('Therapist')
        elif 'psychiatrists' in temp_list:
            table = dynamodb.Table('Psychiatrist')
        elif 'groups' in temp_list:
            table = dynamodb.Table('SupportGroup')
        else:
            table = dynamodb.Table('TreatmentCenter')

        if push_item(table, info_dict) == True:
            open(path.join('uploaded_jsons', item), 'w').close()
            print(item)
    except Exception as error:
        print("Item don\'t download {} : {}".format(item, error))


def init_jsons():
    print('Upload jsons')
    dir_for_upload = listdir('json_files')
    unic_files = parser_utils.get_unic_urls(dir_for_upload, listdir('uploaded_jsons'))
    print('Files for upload:', len(unic_files))
    pool = Pool(8)
    try:
        pool.map(upload_json, unic_files)
        pool.close()
        pool.join()
        pool.terminate()
        sys.exit(1)
    except KeyboardInterrupt:
        print('Stop by user')
        pool.close()
        pool.join()
        pool.terminate()
        sys.exit(1)


def init_images():
    print('Upload images')
    dir_for_upload = listdir('images')
    unic_files = parser_utils.get_unic_urls(dir_for_upload, listdir('uploaded_images'))
    print('Images for upload:', len(unic_files))
    pool = Pool(8)
    try:
        pool.map(upload_image, unic_files)
        pool.close()
        pool.join()
        pool.terminate()
        sys.exit(1)
    except KeyboardInterrupt:
        print('Stop by user')
        pool.close()
        pool.join()
        pool.terminate()
        sys.exit(1)


if __name__ == '__main__':
    p1 = Process(target=init_jsons)
    p1.start()
    p2 = Process(target=init_images)
    p2.start()
    p1.join()
    p2.join()
    sys.exit(1)
