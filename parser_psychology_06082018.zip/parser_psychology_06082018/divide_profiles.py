from modul import parser_utils
from modul import links


def main():
    links_list = parser_utils.get_list_urls_for_pars('profiles.json')
    links.write_list_to_json(links_list[:30000],'profiles_1.json')
    links.write_list_to_json(links_list[30000:60000],'profiles_2.json')
    links.write_list_to_json(links_list[60000:90000],'profiles_3.json')
    links.write_list_to_json(links_list[90000:120000],'profiles_4.json')
    links.write_list_to_json(links_list[120000:150000],'profiles_5.json')
    links.write_list_to_json(links_list[150000:],'profiles_6.json')

    
    



if __name__ == '__main__':
    main()
