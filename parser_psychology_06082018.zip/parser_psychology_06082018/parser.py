from modul import parser_utils
from modul import links
import os
import sys
import time
from multiprocessing import Pool
import shutil
from bs4 import BeautifulSoup
import base64


class Profiler(object):
    def __enter__(self):
        self._startTime = time.time()

    def __exit__(self, type, value, traceback):
        print("Elapsed time: {:.3f} sec".format(time.time() - self._startTime))


def get_states():
    BASE_DICT = {'au': ['counselling', 'groups', 'treatment-rehab'],
                 'ca': ['therapists', 'groups', 'treatment-rehab'],
                 'gb': ['counselling', 'groups', 'treatment-rehab'],
                 'us': ['therapists', 'psychiatrists', 'groups', 'treatment-rehab']}
    base_list = links.get_base_links(BASE_DICT)
    states_link = list()
    for item in base_list:
        page = parser_utils.get_html(item)
        temp = parser_utils.read_html_states(page)
        if len(temp):
            states_link.extend(temp)
    links.write_list_to_json(states_link, 'states.json')


def get_profiles():
    STATES_FILE = 'states.json'
    if not os.path.exists(STATES_FILE):
        print('{} not found. Exit'.format(STATES_FILE))
        sys.exit(1)
    states = links.read_json('states.json')
    try:
        for item in states:
            page = parser_utils.get_html(item)
            item_list = parser_utils.read_html_profiles(page, item)
            if item_list and len(item_list):
                print('New_profiles (state) : {}'.format(len(item_list)))
                links.add_to_json_list(item_list, 'profiles.json')
            links.remove_from_list_in_json(item, 'states.json')
    except KeyboardInterrupt:
        print('Stop by user')
        sys.exit(1)
    except Exception as error:
        print('Exception in get_profiles: ', error)



def get_profiles_city(url):
    name = base64.b64encode(bytes(url, 'utf-8'))
    page = parser_utils.get_html(url)
    parser_utils.read_html_profiles_v2(page, url, name)





def get_city_links():
    STATES_FILE = 'states.json'
    if not os.path.exists(STATES_FILE):
        print('{} not found. Exit'.format(STATES_FILE))
        sys.exit(1)
    states_link = list()
    states = links.read_json('states.json')
    for item in states:
        page = parser_utils.get_html(item)
        item_list = parser_utils.read_html_cities(page, item)
        if item_list:
            states_link.extend(item_list)
    links.write_list_to_json(states_link, 'cities.json')



def get_zip_links(link):
    try:
        page = parser_utils.get_html_profile(link)
        if page:
            temp = parser_utils.read_html_zip(page, link)
            links.add_to_json_list(temp, 'full.json')
        else:
            print('Failed link!!!!:', link)
    except Exception as error:
        print('Failed link!!!!:', link, error)



def read_profiles(link):
    try:
        page = parser_utils.get_html_profile(link)
        if page:
            print(link)
            parser_utils.parse_profiles(page, link)
        else:
            links.write_failed_profile(link)
    except:
        links.write_failed_profile(link)


def fix_failed():
    while True:
        failed_links = parser_utils.get_failed_links()
        links.add_to_json_list(failed_links, 'failed_links.json')
        shutil.rmtree('failed_profiles')
        os.makedirs('failed_profiles')
        links_list = parser_utils.get_unic_urls(parser_utils.get_list_urls_for_pars('failed_links.json'),
                                                parser_utils.get_success_links())
        if len(links_list) == 0:
            break
        try:
            for item in links_list:
                page = parser_utils.get_html(item)
                soap = BeautifulSoup(page, "html.parser")
                if soap.find('div', 'profile-middle profile-flag col-12 col-sm-12 col-md-10 col-lg-10'):
                    parser_utils.parse_profiles(page, item)
                links.remove_from_list_in_json(item, 'failed_links.json')

        except KeyboardInterrupt:
            print('Stop by user')
            sys.exit(1)
        except Exception as error:
            print('Exception in fix_failed: ', error)
        if len(links.read_json("failed_links.json")) == 0 and len(os.listdir('failed_profiles')) == 0:
            break

    sys.exit(1)


def main():
    print('Make your choice:\n1) Get states links\n2) Get profiles links\n3) Get info\n4) Fix failed')
    choice = input('Select:')

    try:
        selected = int(choice)
        if selected not in [1, 2, 3, 4]:
            print('Wrong selected. Input 1, 2, 3 or 4')
    except Exception:
        print('Wrong selected. Input 1, 2, 3 or 4')
        sys.exit(1)

    if selected == 1:
        get_states()
        sys.exit(1)
    elif selected == 2:
        with Profiler() as p:
            get_profiles()
            sys.exit(1)
    elif selected == 3:
        links_list = parser_utils.get_list_urls_for_pars('profiles_.json')

        #links_list = parser_utils.get_unic_urls(links_list, links.read_json('old_upload.json'))

        with Profiler() as p:
            pool = Pool(4)
            pool.map(read_profiles, links_list)
            pool.close()
            pool.join()
            pool.terminate()
        sys.exit(1)
    else:
        fix_failed()
        sys.exit(1)


if __name__ == '__main__':
    main()
    # FILE = 'psychiatrists_2.json'
    # already_in = [base64.b64decode(x[2:-1]).decode("utf-8") for x in os.listdir('cities_links')]
    # temp_warn_links = parser_utils.txt_to_list('warning_links.txt')
    # if temp_warn_links:
    #     warning_links = [x.strip('\n') for x in temp_warn_links if x]
    #     already_in.extend(warning_links)
    # for_pars = parser_utils.get_unic_urls(links.read_json(FILE), already_in )

    # last_page = parser_utils.txt_to_list('last_page_temp.txt')
    # for_pars = [x.strip('\n') for x in last_page if x]
    # for_pars = [x.strip('\n') for x in last_page if x]
    # print('Links for pars: {}'.format(len(for_pars)))
    # with Profiler() as p:
    #     pool = Pool(4)
    #     pool.map(get_profiles_city, for_pars)
    #     pool.close()
    #     pool.join()
    #     pool.terminate()



