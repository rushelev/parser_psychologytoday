import os
from modul import links



def txt_to_list(path_to_file):
    if os.path.exists(path_to_file):
        with open(path_to_file, 'r') as file:
            temp = file.read()
        list_mails = temp[:-1].split(';')
        return list_mails
    else:
        return False

temp = list()
for item in os.listdir('cities_links'):
    temp.extend(txt_to_list(os.path.join('cities_links', item)))

links.add_to_json_list(temp, 'profiles.json')


